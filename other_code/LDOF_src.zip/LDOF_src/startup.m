root_dir=pwd;
addpath(genpath(root_dir));

compileDir;