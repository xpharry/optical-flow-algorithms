To run:
While being inside the folder run startup.m.
Then run  demo_flow_LDOF.m