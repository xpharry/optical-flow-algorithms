function res=psi(s2)
res=sqrt(s2+eps^2);
end